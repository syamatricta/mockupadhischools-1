			<div id="sidebar">
            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(1) ) : ?>
            <?php endif; ?>
			</div>
