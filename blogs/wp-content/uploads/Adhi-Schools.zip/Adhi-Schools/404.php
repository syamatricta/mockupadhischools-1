<?php
	get_header();
?>
		<div id="wpContent">
<?php get_sidebar(); ?>
			<div id="content">
                <h2 class="pagetitle">Error 404 - Not Found</h2>
                <p>You can search it..</p>
                <?php get_search_form(); ?>
            </div>            
		</div>
        
<?php get_footer(); ?>